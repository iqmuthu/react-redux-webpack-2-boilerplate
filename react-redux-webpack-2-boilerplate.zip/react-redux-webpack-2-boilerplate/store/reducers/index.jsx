import { combineReducers } from "redux";
import rootName from "./rootName";
export default combineReducers({
    rootName
});
